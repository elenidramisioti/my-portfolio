-- 1)TOP 10 ARTISTS 
SELECT name, popularity 
FROM artists
ORDER BY popularity DESC
LIMIT 10;

-- 2)SONGS WITH POPULARITY ABOVE AVERAGE
SELECT name, popularity 
FROM tracks
WHERE popularity > (
     SELECT AVG(popularity)
	 FROM tracks
);

-- 3)SONGS THAT INCLUDE THE WORD 'Love'
SELECT name
FROM tracks
WHERE name LIKE '%Love%';

-- 4)ALL INDIVIDUAL ALBUM TYPES
SELECT DISTINCT album_type
FROM albums;

-- 5)AVERAGE POPULARITY PER ARTIST 
SELECT a.name, AVG(t.popularity)
FROM artists a
JOIN r_track_artist rta ON a.id = rta.artist_id
JOIN tracks t ON rta.track_id = t.id
GROUP BY a.name;

-- 6)ARTISTS WITH AVERAGE POPULARITY OVER 10
SELECT a.name, AVG(t.popularity) AS average_popularity
FROM artists a
JOIN r_track_artist rta ON a.id = rta.artist_id
JOIN tracks t ON rta.track_id = t.id
GROUP BY a.name
HAVING AVG(t.popularity) > 10;

-- 7)TOTAL ALBUMS PER ARTIST 
SELECT a.name, COUNT(ra.album_id) AS total_albums
FROM artists a
JOIN r_albums_artists ra ON a.id = ra.artist_id
GROUP BY a.name;

-- 8)ARTISTS WITH OVER 60 SONGS
SELECT a.name, COUNT(rta.track_id) AS total_tracks
FROM artists a
JOIN r_track_artist rta ON a.id = rta.artist_id
GROUP BY a.name
HAVING COUNT(rta.track_id) > 60;

-- 9)SONGS AND ALBUMS(ORDER BY)
SELECT t.name AS track_name, al.name AS album_name
FROM tracks t
JOIN r_albums_tracks rat ON t.id = rat.track_id
JOIN albums al ON rat.album_id = al.id
ORDER BY al.name ASC, t.name ASC;

-- 10)ALL ARTISTS AND THEIR SONGS
SELECT a.name AS artist_name, t.name AS track_name
FROM artists a
LEFT JOIN r_track_artist rta ON a.id = rta.track_id
LEFT JOIN tracks t ON rta.track_id = t.id;

-- 11)ARTISTS WITH MORE FOLLOWERS THAN THE AVERAGE
SELECT name, followers
FROM artists
WHERE followers > (
     SELECT AVG(followers)
	 FROM artists
);

-- 12)ALL ARTISTS AND THEIR ALBUMS IN ONE LIST
SELECT name FROM artists
UNION 
SELECT name FROM ALBUMS;