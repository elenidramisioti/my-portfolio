PRAGMA foreign_keys = ON;

CREATE TABLE albums(id INT PRIMARY KEY, name VARCHAR(255), album_group VARCHAR(255), album_type VARCHAR(255), release_date VARCHAR(255), popularity INT);

CREATE TABLE artists( id INT PRIMARY KEY, name VARCHAR(255), popularity INT, followers INT);

CREATE TABLE genres(name VARCHAR(255) PRIMARY KEY);

CREATE TABLE tracks(id INT PRIMARY KEY, disc_number INT, duration INT, name VARCHAR(255), preview_url TEXT, track_number INT, popularity INT, is_playable INT);

	 
 CREATE TABLE audio_features(track_id INT PRIMARY KEY, acousticness
 REAL, analysis_url TEXT, danceability REAL, duration INT, energy REAL, instrumentalness REAL, key INT, liveness REAL, loudness REAL, speechiness REAL, tempo REAL, time_signature INT, valence REAL, FOREIGN KEY (track_id) REFERENCES tracks(id));

CREATE TABLE r_albums_artists(album_id INT, artist_id INT, PRIMARY KEY(album_id, artist_id), FOREIGN KEY(album_id) REFERENCES albums(id), FOREIGN KEY(artist_id) REFERENCES artists(id));

CREATE TABLE r_albums_tracks(album_id INT, track_id INT, PRIMARY KEY(album_id, track_id), FOREIGN KEY(album_id) REFERENCES albums(id), FOREIGN KEY(track_id) REFERENCES tracks(id));

CREATE TABLE r_artist_genre(genre_name VARCHAR(255), artist_id INT, PRIMARY KEY(genre_name, artist_id), FOREIGN KEY(genre_name) REFERENCES genres(name), FOREIGN KEY(artist_id) REFERENCES artists(id));

CREATE TABLE r_track_artist(track_id INT, artist_id INT, PRIMARY KEY(track_id, artist_id), FOREIGN KEY(track_id) REFERENCES tracks(id), FOREIGN KEY(artist_id) REFERENCES artists(id));
	 